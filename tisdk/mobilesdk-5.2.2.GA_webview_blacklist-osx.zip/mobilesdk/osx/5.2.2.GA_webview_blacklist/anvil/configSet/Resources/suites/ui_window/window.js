var curWin = Ti.UI.currentWindow; 
var l1 = Ti.UI.createLabel({
    top:20
})
curWin.add(l1);
 
 

