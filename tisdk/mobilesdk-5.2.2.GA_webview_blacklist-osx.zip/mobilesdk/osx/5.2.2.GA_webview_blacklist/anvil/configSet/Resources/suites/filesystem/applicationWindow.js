exports.ApplicationWindow = function() {
	//create object instance
	var self = Ti.UI.createWindow();
	return self;
};