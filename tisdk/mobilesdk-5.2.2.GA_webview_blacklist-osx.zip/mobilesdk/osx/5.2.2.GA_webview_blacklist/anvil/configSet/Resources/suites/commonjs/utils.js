exports.foo = function() {
    return true;
}