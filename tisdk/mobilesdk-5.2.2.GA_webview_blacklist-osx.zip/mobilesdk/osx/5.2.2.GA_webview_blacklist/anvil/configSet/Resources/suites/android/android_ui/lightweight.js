// Added for test for https://appcelerator.lighthouseapp.com/projects/32238/tickets/2505
var win = Ti.UI.currentWindow;

