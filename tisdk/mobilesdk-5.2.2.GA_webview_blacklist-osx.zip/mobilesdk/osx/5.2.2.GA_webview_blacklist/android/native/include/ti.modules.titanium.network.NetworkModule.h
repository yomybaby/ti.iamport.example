/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2011-2013 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */

/** This is generated, do not edit by hand. **/

#include <jni.h>

#include "Proxy.h"

		namespace titanium {


class NetworkModule : public titanium::Proxy
{
public:
	explicit NetworkModule(jobject javaObject);

	static void bindProxy(v8::Handle<v8::Object> exports);
	static v8::Handle<v8::FunctionTemplate> getProxyTemplate();
	static void dispose();

	static v8::Persistent<v8::FunctionTemplate> proxyTemplate;
	static jclass javaClass;

private:
	// Methods -----------------------------------------------------------
	static v8::Handle<v8::Value> addSystemCookie(const v8::Arguments&);
	static v8::Handle<v8::Value> removeHTTPCookiesForDomain(const v8::Arguments&);
	static v8::Handle<v8::Value> removeAllHTTPCookies(const v8::Arguments&);
	static v8::Handle<v8::Value> removeHTTPCookie(const v8::Arguments&);
	static v8::Handle<v8::Value> getOnline(const v8::Arguments&);
	static v8::Handle<v8::Value> getHTTPCookies(const v8::Arguments&);
	static v8::Handle<v8::Value> encodeURIComponent(const v8::Arguments&);
	static v8::Handle<v8::Value> getSystemCookies(const v8::Arguments&);
	static v8::Handle<v8::Value> addHTTPCookie(const v8::Arguments&);
	static v8::Handle<v8::Value> removeSystemCookie(const v8::Arguments&);
	static v8::Handle<v8::Value> getNetworkType(const v8::Arguments&);
	static v8::Handle<v8::Value> removeAllSystemCookies(const v8::Arguments&);
	static v8::Handle<v8::Value> getNetworkTypeName(const v8::Arguments&);
	static v8::Handle<v8::Value> getHTTPCookiesForDomain(const v8::Arguments&);
	static v8::Handle<v8::Value> decodeURIComponent(const v8::Arguments&);

	// Dynamic property accessors ----------------------------------------
	static v8::Handle<v8::Value> getter_networkType(v8::Local<v8::String> property, const v8::AccessorInfo& info);
	static v8::Handle<v8::Value> getter_online(v8::Local<v8::String> property, const v8::AccessorInfo& info);
	static v8::Handle<v8::Value> getter_networkTypeName(v8::Local<v8::String> property, const v8::AccessorInfo& info);

};

		} // titanium
