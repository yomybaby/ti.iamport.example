{
	"output format": "формат виведення",
	"the key to get or set": "ключ",
	"the value to set the specified key": "значення для вказанного ключа",
	"Invalid key \"%s\"": "Невірний ключ \"%s\""
}